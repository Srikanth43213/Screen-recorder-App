import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

// Optional cloud storage (Cloudinary) for Render deployment
import { v2 as cloudinary } from 'cloudinary';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 8080;
const ORIGIN = process.env.ORIGIN || '*';
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'data', 'recordings.db');
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, 'uploads');

// Init dirs
fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

app.use(cors({ origin: ORIGIN }));
app.use(morgan('dev'));
app.use(express.json());

// Static serving for local file storage
app.use('/uploads', express.static(UPLOAD_DIR));

// Configure multer for local storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, UPLOAD_DIR);
  },
  filename: function (req, file, cb) {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname) || '.webm';
    cb(null, unique + ext);
  }
});
const upload = multer({ storage });

// Cloudinary (optional)
const cloudinaryEnabled = !!process.env.CLOUDINARY_URL;
if (cloudinaryEnabled) {
  cloudinary.config({ secure: true });
  console.log('Cloudinary upload enabled');
} else {
  console.log('Cloudinary not configured. Using local storage at', UPLOAD_DIR);
}

// SQLite
let db;
async function initDb() {
  db = await open({
    filename: DB_FILE,
    driver: sqlite3.Database
  });
  await db.exec(`
    CREATE TABLE IF NOT EXISTS recordings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT,
      filename TEXT NOT NULL,
      size INTEGER NOT NULL,
      url TEXT NOT NULL,
      createdAt TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
  console.log('SQLite DB ready at', DB_FILE);
}

// API

// Upload recording
app.post('/api/recordings', upload.single('recording'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const title = req.body.title || req.file.originalname || 'Untitled Recording';

    let fileUrl;
    let storedFilename = req.file.filename;
    let fileSize = req.file.size;

    if (cloudinaryEnabled) {
      // Upload the file from local disk to Cloudinary as a "video" (supports webm)
      const uploaded = await cloudinary.uploader.upload(req.file.path, {
        resource_type: 'video',
        folder: 'screen-recordings'
      });
      fileUrl = uploaded.secure_url;
      // Optionally delete local file after successful upload
      fs.unlink(req.file.path, () => {});
      storedFilename = path.basename(uploaded.public_id);
      fileSize = req.file.size; // Cloudinary doesn't return original bytes reliably; keep local size
    } else {
      // Local static URL
      fileUrl = `${req.protocol}://${req.get('host')}/uploads/${storedFilename}`;
    }

    const result = await db.run(
      'INSERT INTO recordings (title, filename, size, url) VALUES (?, ?, ?, ?)',
      title, storedFilename, fileSize, fileUrl
    );
    const inserted = await db.get('SELECT * FROM recordings WHERE id = ?', result.lastID);
    res.status(201).json(inserted);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Upload failed' });
  }
});

// List recordings
app.get('/api/recordings', async (req, res) => {
  try {
    const items = await db.all('SELECT * FROM recordings ORDER BY datetime(createdAt) DESC');
    res.json(items);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch recordings' });
  }
});

// Get a single recording
app.get('/api/recordings/:id', async (req, res) => {
  try {
    const item = await db.get('SELECT * FROM recordings WHERE id = ?', req.params.id);
    if (!item) return res.status(404).json({ error: 'Not found' });
    // For local storage, we can redirect to the static URL
    return res.redirect(item.url);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch recording' });
  }
});

// Health
app.get('/api/health', (_req, res) => res.json({ ok: true }));

// Start
initDb().then(() => {
  app.listen(PORT, () => {
    console.log(`Backend listening on port ${PORT}`);
  });
});
