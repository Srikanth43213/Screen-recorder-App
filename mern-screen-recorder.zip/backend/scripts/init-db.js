import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

dotenv.config();

const DB_FILE = process.env.DB_FILE || './data/recordings.db';
fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });

const db = await open({ filename: DB_FILE, driver: sqlite3.Database });
await db.exec(`
  CREATE TABLE IF NOT EXISTS recordings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    filename TEXT NOT NULL,
    size INTEGER NOT NULL,
    url TEXT NOT NULL,
    createdAt TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);
console.log('DB initialized at', DB_FILE);
process.exit(0);
