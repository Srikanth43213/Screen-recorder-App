import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import App from './pages/App.jsx'
import List from './pages/List.jsx'
import './styles.css'

const Root = () => (
  <BrowserRouter>
    <div className="container">
      <header>
        <h1>Screen Recorder</h1>
        <nav>
          <Link to="/">Record</Link>
          <Link to="/recordings">Recordings</Link>
        </nav>
      </header>
      <Routes>
        <Route path="/" element={<App />} />
        <Route path="/recordings" element={<List />} />
      </Routes>
    </div>
  </BrowserRouter>
)

createRoot(document.getElementById('root')).render(<Root />)
