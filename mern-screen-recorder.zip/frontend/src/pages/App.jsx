import React, { useEffect, useRef, useState } from 'react'

const MAX_SECONDS = 180 // 3 minutes

const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:8080'

export default function App() {
  const [recording, setRecording] = useState(false)
  const [timer, setTimer] = useState(0)
  const [mediaRecorder, setMediaRecorder] = useState(null)
  const [chunks, setChunks] = useState([])
  const [blobUrl, setBlobUrl] = useState(null)
  const [title, setTitle] = useState('My Recording')
  const [status, setStatus] = useState('')
  const timeoutRef = useRef(null)
  const intervalRef = useRef(null)
  const combinedStreamRef = useRef(null)

  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
      if (timeoutRef.current) clearTimeout(timeoutRef.current)
      if (combinedStreamRef.current) {
        combinedStreamRef.current.getTracks().forEach(t => t.stop())
      }
    }
  }, [])

  const start = async () => {
    setStatus('')
    setBlobUrl(null)
    setChunks([])
    setTimer(0)
    try {
      // Get display (tab) with system audio if available
      const display = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: 30 },
        audio: true // tab/system audio (Chrome)
      })
      // Get microphone
      let mic = null
      try {
        mic = await navigator.mediaDevices.getUserMedia({ audio: true })
      } catch (e) {
        console.warn('Mic not available or denied, proceeding with display audio only')
      }

      const tracks = [
        ...display.getVideoTracks(),
        ...display.getAudioTracks()
      ]
      if (mic) tracks.push(...mic.getAudioTracks())
      const combined = new MediaStream(tracks)
      combinedStreamRef.current = combined

      const mr = new MediaRecorder(combined, { mimeType: 'video/webm;codecs=vp8,opus' })
      mr.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          setChunks(prev => [...prev, e.data])
        }
      }
      mr.onstop = () => {
        const blob = new Blob(chunks, { type: 'video/webm' })
        const url = URL.createObjectURL(blob)
        setBlobUrl(url)
        if (combinedStreamRef.current) {
          combinedStreamRef.current.getTracks().forEach(t => t.stop())
          combinedStreamRef.current = null
        }
      }
      mr.start(250) // timeslice to gather data periodically
      setMediaRecorder(mr)
      setRecording(true)

      // timer
      intervalRef.current = setInterval(() => {
        setTimer(prev => prev + 1)
      }, 1000)

      // hard stop at 3 mins
      timeoutRef.current = setTimeout(() => {
        stop()
      }, MAX_SECONDS * 1000)
    } catch (err) {
      console.error(err)
      setStatus('Permission denied or no capture devices available.')
    }
  }

  const stop = () => {
    if (intervalRef.current) clearInterval(intervalRef.current)
    if (timeoutRef.current) clearTimeout(timeoutRef.current)
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop()
    }
    setRecording(false)
  }

  const download = () => {
    const blob = new Blob(chunks, { type: 'video/webm' })
    const a = document.createElement('a')
    a.href = window.URL.createObjectURL(blob)
    a.download = (title || 'recording') + '.webm'
    a.click()
    window.URL.revokeObjectURL(a.href)
  }

  const upload = async () => {
    try {
      setStatus('Uploading...')
      const blob = new Blob(chunks, { type: 'video/webm' })
      const fd = new FormData()
      fd.append('title', title || 'Untitled Recording')
      fd.append('recording', blob, (title || 'recording') + '.webm')
      const res = await fetch(`${apiUrl}/api/recordings`, { method: 'POST', body: fd })
      if (!res.ok) throw new Error('Upload failed')
      const data = await res.json()
      setStatus('Uploaded! ID: ' + data.id)
    } catch (e) {
      console.error(e)
      setStatus('Upload failed. Check backend URL / CORS.')
    }
  }

  const mm = Math.floor(timer / 60).toString().padStart(2, '0')
  const ss = (timer % 60).toString().padStart(2, '0')

  return (
    <div>
      <div className="card">
        <div className="stack">
          <button onClick={start} disabled={recording}>Start</button>
          <button onClick={stop} disabled={!recording}>Stop</button>
          <div className="timer">{mm}:{ss}</div>
          <input
            type="text"
            placeholder="Title"
            value={title}
            onChange={e => setTitle(e.target.value)}
          />
        </div>
        {status && <p>{status}</p>}
      </div>

      {blobUrl && (
        <div className="card">
          <div className="row">
            <strong>Preview</strong>
            <div className="stack">
              <button onClick={download}>Download</button>
              <button onClick={upload}>Upload</button>
            </div>
          </div>
          <video controls src={blobUrl} />
        </div>
      )}

      <p><small>Tip: Chrome required for tab capture. Permission prompts will appear for screen and mic.</small></p>
    </div>
  )
}
