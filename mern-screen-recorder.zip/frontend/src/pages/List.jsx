import React, { useEffect, useState } from 'react'

const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:8080'

export default function List() {
  const [items, setItems] = useState([])
  const [error, setError] = useState('')

  const load = async () => {
    try {
      const res = await fetch(`${apiUrl}/api/recordings`)
      const data = await res.json()
      setItems(data)
    } catch (e) {
      console.error(e)
      setError('Failed to fetch recordings')
    }
  }
  useEffect(() => { load() }, [])

  return (
    <div>
      <h2>Uploaded Recordings</h2>
      {error && <p>{error}</p>}
      {items.length === 0 && <p>No recordings yet.</p>}
      {items.map(r => (
        <div key={r.id} className="card">
          <div className="row">
            <div>
              <div><strong>{r.title || 'Untitled'}</strong></div>
              <div><small>Size: {(r.size/1024/1024).toFixed(2)} MB</small></div>
              <div><small>Created: {new Date(r.createdAt).toLocaleString()}</small></div>
            </div>
            <a href={r.url} target="_blank" rel="noreferrer">Open</a>
          </div>
          {/* Inline player */}
          {r.url.endsWith('.mp3') || r.url.endsWith('.wav') ? (
            <audio controls src={r.url} />
          ) : (
            <video controls src={r.url} />
          )}
        </div>
      ))}
    </div>
  )
}
